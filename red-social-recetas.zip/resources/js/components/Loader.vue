<template>
	<div class="container-loader">
		<div class="lds-ellipsis">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
		<div class="text-center">
			{{ mensaje }}
		</div>
	</div>
</template>

<script>
import Vue from "vue";

export default Vue.extend({
	props: {
		mensaje: {
			type: String,
			default: "Cargando...",
		},
	},
	data() {
		return {};
	},
	methods: {},
});
</script>

<style scoped>
.container-loader {
	text-align: center;
	margin: 1rem auto;
}
.lds-ellipsis {
	display: inline-block;
	position: relative;
	width: 150px;
	height: 37px;
}
.lds-ellipsis div {
	position: absolute;
	top: 6px;
	width: 25px;
	height: 25px;
	border-radius: 50%;
	background: rgb(199, 199, 199);
	animation-timing-function: cubic-bezier(0, 1, 1, 0);
}
.lds-ellipsis div:nth-child(1) {
	left: 6px;
	animation: lds-ellipsis1 0.6s infinite;
}
.lds-ellipsis div:nth-child(2) {
	left: 6px;
	animation: lds-ellipsis2 0.6s infinite;
}
.lds-ellipsis div:nth-child(3) {
	left: 62.5px;
	animation: lds-ellipsis2 0.6s infinite;
}
.lds-ellipsis div:nth-child(4) {
	left: 119px;
	animation: lds-ellipsis3 0.6s infinite;
}
@keyframes lds-ellipsis1 {
	0% {
		transform: scale(0);
	}
	100% {
		transform: scale(1);
	}
}
@keyframes lds-ellipsis3 {
	0% {
		transform: scale(1);
	}
	100% {
		transform: scale(0);
	}
}
@keyframes lds-ellipsis2 {
	0% {
		transform: translate(0, 0);
	}
	100% {
		transform: translate(56.5px, 0);
	}
}
</style>
