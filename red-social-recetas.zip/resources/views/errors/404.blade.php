@extends('errors::custom-layout2')

@section('title', __('No encontrado'))

@section('code', '404')
@section('message', __('Lo sentimos, la página que estás buscando no se ha encontrado.'))
