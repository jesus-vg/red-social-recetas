@extends('errors::custom-layout2')

@section('title', __('Pagina expirada'))
@section('code', '419')
@section('message', __('La pagina actual ha expirado'))
