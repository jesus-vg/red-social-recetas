<?php $__env->startSection('styles'); ?>
	<link
		rel="stylesheet"
		href="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.9/dist/css/splide.min.css"
	>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('hero'); ?>
	<div class="hero-search">
		<form
			class="container h-100"
			action="<?php echo e(route('recetas.search')); ?>"
			method="GET"
		>
			<div class="row h-100 align-items-center">
				<div class="col-md-4 hero-search__search">
					<p class="display-4">Encuentra una receta para tu proxima comida</p>

					<input
						type="search"
						class="form-control"
						name="buscar"
						aria-describedby="Buscar recetas"
						placeholder="Buscar..."
						value="<?php echo e(old('buscar', '')); ?>"
					>

					<?php $__errorArgs = ['buscar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger bg-white py-2 d-block">
							<?php echo e($message); ?>

						</small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<h1 class="h1 mb-3">
		Últimas recetas
	</h1>
	<ultimas-recetas data="<?php echo e(json_encode($recetas_recientes)); ?>"></ultimas-recetas>

	
	<h2 class="title mt-5">Nuestras últimas entradas por categoría</h2>

	<galeria-recetas-categoria
		recetas="<?php echo e(json_encode($recetas_por_categoria)); ?>"
		categoria="<?php echo e('categoria'); ?>"
	>
	</galeria-recetas-categoria>

	
	<h2 class="title mt-5">Nuestras recetas más votadas</h2>
	<?php echo $__env->make('ui/galeria-recetas', ['recetas' => $recetas_mas_votadas], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/inicio/index.blade.php ENDPATH**/ ?>