<?php $__env->startSection('styles'); ?>

	<style>
		.img {
			filter: drop-shadow(2px 4px 6px black);
		}

	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row justify-content-center">
		<div class="col-md-4 d-none d-sm-block">
			<img
				src="<?php echo e(asset('images/chef.png')); ?>"
				class="img-fluid img my-5"
				alt="error 404"
			>
		</div>
		<div class="col-md-6 order-first order-sm-last text-center">
			<div class="wrapper__content h-100 d-flex justify-content-center align-items-center flex-column">
				<h1 class="display-2"><?php echo $__env->yieldContent('code'); ?></h1>
				<p class="lead"><?php echo $__env->yieldContent('message'); ?></p>
				<hr class="my-4 w-50">
				<a
					href="<?php echo e(url('/')); ?>"
					class="btn btn-primary"
				>Ir al inicio</a>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/errors/custom-layout2.blade.php ENDPATH**/ ?>