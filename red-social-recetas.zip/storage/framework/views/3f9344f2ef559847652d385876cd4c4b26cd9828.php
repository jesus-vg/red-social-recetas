<?php $__env->startSection('title', __('No encontrado')); ?>

<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('Lo sentimos, la página que estás buscando no se ha encontrado.')); ?>

<?php echo $__env->make('errors::custom-layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/errors/404.blade.php ENDPATH**/ ?>