<?php $__env->startSection('botones'); ?>
	<a
		href="<?php echo e(route('profile.edit', ['perfil' => $perfil->id])); ?>"
		class="btn btn-primary"
	>
		<i class="fa fa-arrow-left"></i> Editar
	</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	
	
	<h2 class="h2 text-center mb-2 text-primary">
		<?php echo e($perfil->user->name); ?>

	</h2>

	<div class="text-center mb-3 mt-2">
		<a
			href="<?php echo e($perfil->user->url); ?>"
			target="_blank"
		>
			Visitar sitio web
		</a>
	</div>

	<div class="biografia">
		<?php if($perfil->imagen): ?>
			<div class="row">
				<div class="col-12 col-md-4">
					<img
						data-src="<?php echo e(asset('storage/' . $perfil->imagen)); ?>"
						class="img-fluid lazyload"
						alt="<?php echo e($perfil->user->name); ?>"
					>
				</div>

				<div class="col-12 col-md-8">
					<?php echo $perfil->biografia; ?>

				</div>
			</div>
		<?php else: ?>
			<?php echo $perfil->biografia; ?>

		<?php endif; ?>
	</div>

	<div class="recetas-creadas">
		
		<h3 class="h3 text-center mb-3 text-primary">
			Recetas creadas por <?php echo e($perfil->user->name); ?>

		</h3>
		<recetas-scroll-infinito :id-usuario="<?php echo e($perfil->id); ?>"></recetas-scroll-infinito>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/perfiles/show.blade.php ENDPATH**/ ?>