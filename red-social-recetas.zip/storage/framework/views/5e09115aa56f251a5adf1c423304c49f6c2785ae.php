<?php $__env->startSection('styles'); ?>
	<link
		rel="stylesheet"
		href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.min.css"
		integrity="sha512-5m1IeUDKtuFGvfgz32VVD0Jd/ySGX7xdLxhqemTmThxHdgqlgPdupWoSN8ThtUSLpAGBvA8DY2oO7jJCrGdxoA=="
		crossorigin="anonymous"
		referrerpolicy="no-referrer"
	/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('botones'); ?>
	<a
		href="<?php echo e(route('profile.show', ['perfil' => $perfil->id])); ?>"
		class="btn btn-primary"
	>
		<i class="fa fa-arrow-left"></i> Volver
	</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1 class="h1 text-center">
		Editar perfil
	</h1>
	
	
	<div class="row">
		<div class="col-12">
			<?php if(Session::get('success')): ?>
				<div
					class="alert alert-primary"
					role="alert"
				>
					<?php echo e(Session::get('success')); ?>

				</div>
			<?php endif; ?>
			<?php if(Session::get('error')): ?>
				<div
					class="alert alert-danger"
					role="alert"
				>
					<?php echo e(Session::get('error')); ?>

				</div>
			<?php endif; ?>
		</div>
		<div class="col-12">
			<form
				action="<?php echo e(route('profile.update', ['perfil' => $perfil->user->id])); ?>"
				method="POST"
				enctype="multipart/form-data"
			>
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>

				<div class="form-group">
					<label for="name">Nombre</label>
					<input
						type="text"
						name="name"
						id="name"
						class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
						value="<?php echo e(old('name', $perfil->user->name)); ?>"
						placeholder="Tu nombre"
					>
					<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span
							class="invalid-feedback"
							role="alert"
						>
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				
				<div class="form-group">
					<label for="url">Sitio web</label>
					<input
						type="text"
						name="url"
						id="url"
						class="form-control <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
						value="<?php echo e(old('url', $perfil->user->url)); ?>"
						placeholder="Tu sitio web"
					>
					<?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span
							class="invalid-feedback"
							role="alert"
						>
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				
				<div class="form-group">
					<label for="biografia">Biografía</label>
					<input
						type="hidden"
						id="biografia"
						name="biografia"
						value="<?php echo e(old('biografia', $perfil->biografia)); ?>"
					>
					<trix-editor
						input="biografia"
						class="form-control h-auto <?php $__errorArgs = ['biografia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
						placeholder="Tu biografía ..."
					></trix-editor>
					<?php $__errorArgs = ['biografia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div
							class="invalid-feedback"
							role="alert"
						>
							<strong><?php echo e($message); ?></strong>
						</div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				
				<div class="form-group">

					<?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span
							class="invalid-feedback"
							role="alert"
						>
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

					<recortar-imagen imagen="<?php echo e(Storage::url($perfil->imagen)); ?>"></recortar-imagen>
				</div>

				<div class="form-group">
					<button
						type="submit"
						class="btn btn-primary"
					>
						Guardar
					</button>
				</div>
			</form>
		</div>
	</div>

	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script
	 src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.min.js"
	 integrity="sha512-2RLMQRNr+D47nbLnsbEqtEmgKy67OSCpWJjJM394czt99xj3jJJJBQ43K7lJpfYAYtvekeyzqfZTx2mqoDh7vg=="
	 crossorigin="anonymous"
	 referrerpolicy="no-referrer"
	 defer
	></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/perfiles/edit.blade.php ENDPATH**/ ?>