<?php $__env->startSection('content'); ?>
	
	<article>
		<h1 class="h1 text-center"><?php echo e($receta->titulo); ?></h1>
		<div class="banner my-4">
			<img
				src="/storage/<?php echo e($receta->imagen); ?>"
				class="rounded"
				alt="<?php echo e($receta->titulo); ?>"
			>
			<div class="mask"></div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<p>
					<span class="font-weit-bold text-primary">Escrito en: </span>
					<a href="<?php echo e(route('categorias.show', ['categoria' => $receta->categoria_id])); ?>">
						<?php echo e($receta->categories->nombre); ?>

					</a>
				</p>
			</div>
			<div class="col-md-6 text-md-right">
				<p>
					<span class="font-weit-bold text-primary">Por: </span>
					<a href="<?php echo e(route('profile.show', [$receta->getAuthor->id])); ?>"><?php echo e($receta->getAuthor->name); ?></a>
				</p>
			</div>
		</div>

		<p>
			<span class="font-weit-bold text-primary">Fecha: </span>
			<fecha-receta fecha="<?php echo e($receta->created_at); ?>"></fecha-receta>
		</p>

		<div class="ingredientes mb-4">
			<h2 class="h2 text-primary">Ingredientes</h2>
			<?php echo $receta->ingredientes; ?>

		</div>

		<div class="preparacion">
			<h2 class="h2 text-primary">Preparación</h2>
			<?php echo $receta->preparacion; ?>

		</div>

		
		<likes
			:id-receta="<?php echo e($receta->id); ?>"
			:total-likes="<?php echo e($likes->total_likes); ?>"
			:liked="<?php echo e($likes->liked ? 'true' : 'false'); ?>"
		></likes>

	</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/recetas/show.blade.php ENDPATH**/ ?>