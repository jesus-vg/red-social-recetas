<?php $__env->startSection('styles'); ?>
	<link
		rel="stylesheet"
		href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.min.css"
		integrity="sha512-5m1IeUDKtuFGvfgz32VVD0Jd/ySGX7xdLxhqemTmThxHdgqlgPdupWoSN8ThtUSLpAGBvA8DY2oO7jJCrGdxoA=="
		crossorigin="anonymous"
		referrerpolicy="no-referrer"
	/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('botones'); ?>
	<a
		href="<?php echo e(route('recetas.index')); ?>"
		class="btn btn-primary"
	>
		<i class="fa fa-arrow-left"></i> Volver
	</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2 class="h2 text-center">Agregar nueva receta</h2>

	<div class="container">
		<form
			method="POST"
			action="<?php echo e(route('recetas.store')); ?>"
			novalidate
			enctype="multipart/form-data"
		>
			<?php echo csrf_field(); ?>
			<div class="form-group row">
				<label
					for="titulo"
					class="col-sm-12 col-form-label"
				>Titulo</label>
				<div class="col-sm-12">
					<input
						type="text"
						class="form-control <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
						name="titulo"
						id="titulo"
						placeholder="Titulo de la receta"
						value="<?php echo e(old('titulo')); ?>"
					>
					<?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div
							class="invalid-feedback"
							role="alert"
						>
							<strong><?php echo e($message); ?></strong>
						</div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="form-group">
				<label for="categoria">Categoría</label>
				<select
					class="custom-select <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
					name="categoria"
					id="categoria"
				>
					<option>Seleccione</option>
					<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option
							value="<?php echo e($categoria->id); ?>"
							<?php echo e(old('categoria') == $categoria->id ? 'selected' : ''); ?>

						><?php echo e($categoria->nombre); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				<?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div
						class="invalid-feedback"
						role="alert"
					>
						<strong><?php echo e($message); ?></strong>
					</div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="form-group">
				<label for="preparacion">Preparación</label>
				<input
					id="preparacion"
					type="hidden"
					name="preparacion"
					value="<?php echo e(old('preparacion')); ?>"
				>
				<trix-editor
					input="preparacion"
					class="form-control h-auto <?php $__errorArgs = ['preparacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
					placeholder="Preparación de la receta ..."
				></trix-editor>
				<?php $__errorArgs = ['preparacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div
						class="invalid-feedback"
						role="alert"
					>
						<strong><?php echo e($message); ?></strong>
					</div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="form-group">
				<label for="ingredientes">Ingredientes</label>
				<input
					id="ingredientes"
					type="hidden"
					name="ingredientes"
					value="<?php echo e(old('ingredientes')); ?>"
				>
				<trix-editor
					input="ingredientes"
					class="form-control h-auto <?php $__errorArgs = ['ingredientes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
					placeholder="Ingredientes de la receta ..."
				></trix-editor>
				<?php $__errorArgs = ['ingredientes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div
						class="invalid-feedback"
						role="alert"
					>
						<strong><?php echo e($message); ?></strong>
					</div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="form-group">
				<label for="imagen">Imagenes ilustrativas</label>
				<input
					type="file"
					class="form-control-file <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
					name="imagen"
					id="imagen"
					placeholder="Seleccione algunas imagenes"
					aria-describedby="fileHelpId"
				>
				<small
					id="fileHelpId"
					class="form-text text-muted"
				>Seleccione una o varias imagenes</small>
				<?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div
						class="invalid-feedback"
						role="alert"
					>
						<strong><?php echo e($message); ?></strong>
					</div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="form-group row">
				<div class="text-center col-sm-12">
					<button
						type="submit"
						class="btn btn-primary"
					>Agregar receta</button>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script
	 src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.min.js"
	 integrity="sha512-2RLMQRNr+D47nbLnsbEqtEmgKy67OSCpWJjJM394czt99xj3jJJJBQ43K7lJpfYAYtvekeyzqfZTx2mqoDh7vg=="
	 crossorigin="anonymous"
	 referrerpolicy="no-referrer"
	 defer
	></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/recetas/create.blade.php ENDPATH**/ ?>