<?php $__env->startSection('content'); ?>
	<h2 class="title mb-5">Categoria: <?php echo e($categoria->nombre); ?></h2>
	<?php echo $__env->make('ui/galeria-recetas', ['recetas' => $recetas], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
	<div class="d-flex justify-content-center mt-5">
		<?php echo e($recetas->links('pagination::bootstrap-4')); ?>

	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/categorias/show.blade.php ENDPATH**/ ?>