<?php $__env->startSection('botones'); ?>
	<a
		href="<?php echo e(route('recetas.create')); ?>"
		class="btn btn-primary"
	>Crear nueva receta</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1 class="h1 text-center">Administra tus recetas</h1>

	
	<?php if(count($recetas) > 0): ?>
		<table class="table mt-4 table-striped tabla-recetas">
			<thead class="bg-primary text-white">
				<tr>
					<th>Titulo</th>
					<th>Categoría</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td scope="row"><?php echo e($receta->titulo); ?></td>
						<td><?php echo e($receta->categories->nombre); ?></td>
						<td>
							<eliminar-receta
								receta-id="<?php echo e($receta->id); ?>"
								receta-titulo="<?php echo e($receta->titulo); ?>"
							></eliminar-receta>

							<a
								href="<?php echo e(route('recetas.edit', ['receta' => $receta->id])); ?>"
								class="btn btn-primary btn-sm"
							>Editar</a>

							<a
								href="<?php echo e(route('recetas.show', ['receta' => $receta->id])); ?>"
								class="btn btn-info btn-sm"
							>Ver</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		
		<div class="d-flex justify-content-center">
			
			<?php echo e($recetas->links('pagination::bootstrap-4')); ?>

		</div>
	<?php else: ?>
		
		<div
			class="alert alert-info mt-4 text-center py-5"
			role="alert"
		>
			<strong>No tienes recetas creadas</strong>
		</div>
	<?php endif; ?>

	
	<h2 class="h2 mt-5 text-center">Recetas que te gustan</h2>

	
	<?php if(count($recetasLikes) > 0): ?>
		<div class="list-group">
			<?php $__currentLoopData = $recetasLikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a
					href="<?php echo e(route('recetas.show', ['receta' => $receta->id])); ?>"
					class="list-group-item list-group-item-action"
				>
					<?php echo e($receta->titulo); ?>

				</a>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

		
		<div class="d-flex justify-content-center">
			
			<?php echo e($recetasLikes->links('pagination::bootstrap-4')); ?>

		</div>
	<?php else: ?>
		
		<div
			class="alert alert-info mt-4 text-center py-5"
			role="alert"
		>
			<strong>Aun no te gustan recetas, selecciona una para darle like!</strong>
			<br>
			Las recetas que te gustan se mostrarán aqui, cuando te guste una receta, la podras ver aqui.
		</div>
	<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/recetas/index.blade.php ENDPATH**/ ?>