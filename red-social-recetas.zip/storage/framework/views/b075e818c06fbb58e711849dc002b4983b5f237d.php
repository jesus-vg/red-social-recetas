<div class="gallery-flex">

	<?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="gallery-flex__item">
			<div class="gallery-flex__item--header">
				<img
					data-src="<?php echo e(asset('storage/' . $receta['imagen'])); ?>"
					class="lazyload"
					alt="<?php echo e($receta['titulo']); ?>"
				>
			</div>
			<div class="gallery-flex__item--body">
				<h3><?php echo e($receta['titulo']); ?></h3>
				<div class="d-flex justify-content-between my-2">
					<div class="text-primary">
						<fecha-receta fecha="<?php echo e($receta['created_at']); ?>"></fecha-receta>
					</div>
					<div class="likes-receta">
						<?php echo e($receta['likes_count']); ?> Les gustó
					</div>
				</div>
				<p>
					<?php echo e(html_entity_decode($receta['preparacion'])); ?>

				</p>
			</div>
			<div class="gallery-flex__item--footer">
				<a
					href="<?php echo e(route('recetas.show', ['receta' => $receta['id']])); ?>"
					class="btn btn-primary"
				>Ver</a>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/ui/galeria-recetas.blade.php ENDPATH**/ ?>