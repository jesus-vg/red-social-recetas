<?php $__env->startSection('content'); ?>

	<h1 class="h1 mb-3">
		Resutados de la búsqueda:
	</h1>

	
	<?php
	// total de registros encontrados
	$cantidad = $recetas->total();

	// personalizar el mensaje según la cantidad de registros encontrados
	if ($cantidad == 0) {
					$mensaje = 'No se encontraron recetas con el nombre: ' . $busqueda;
	} elseif ($cantidad == 1) {
					$mensaje = 'Se encontró 1 receta con el nombre: ' . $busqueda;
	} else {
					$mensaje = 'Se encontraron ' . $cantidad . ' recetas con el nombre: ' . $busqueda;
	}
	?>
	<h2 class="title mt-5"><?php echo e($mensaje); ?></h2>

	
	<div class="gallery-flex">

		<?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="gallery-flex__item">
				<div class="gallery-flex__item--header">
					<img
						data-src="<?php echo e(asset('storage/' . $receta['imagen'])); ?>"
						class="lazyload"
						alt="<?php echo e($receta['titulo']); ?>"
					>
				</div>
				<div class="gallery-flex__item--body">
					<h3><?php echo e($receta['titulo']); ?></h3>
					<div class="d-flex justify-content-between my-2">
						<div class="text-primary">
							<fecha-receta fecha="<?php echo e($receta['created_at']); ?>"></fecha-receta>
						</div>
						<div class="likes-receta">
							<?php echo e($receta['likes_count']); ?> Les gustó
						</div>
					</div>
					<p>
						<?php
							$preparacion = Str::words(strip_tags($receta['preparacion']), 15);
						?>
						<?php echo e(html_entity_decode($preparacion)); ?>

					</p>
				</div>
				<div class="gallery-flex__item--footer">
					<a
						href="<?php echo e(route('recetas.show', ['receta' => $receta['id']])); ?>"
						class="btn btn-primary"
					>Ver</a>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	
	<div class="d-flex justify-content-center">
		<?php echo e($recetas->links('pagination::bootstrap-4')); ?>

	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jesus\programacion\cursos\php\udemy-juan-de-la-torre\red-social-recetas\resources\views/busquedas/show.blade.php ENDPATH**/ ?>